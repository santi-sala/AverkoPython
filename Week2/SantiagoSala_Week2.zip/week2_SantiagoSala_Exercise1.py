print("Santiago Sala")
print("Week 2 Tasks")
print("Exercise 1: Variables")
im_integer = 999999
im_float = 5.55555555555
im_string = 'x'
im_string_two = "Kokkola"
im_float_two = 2.33
im_integer_two = 10
im_integer_three = 300
im_integer_four = 9000000000
im_integer_five = 3000000000000

print(type(im_integer))
print(type(im_float))
print(type(im_string))
print(type(im_string_two))
print(type(im_float_two))
print(type(im_integer_two))
print(type(im_integer_three))
print(type(im_integer_four))
print(type(im_integer_five))


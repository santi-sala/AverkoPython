import random

print("Santiago Sala")
print("Week 5 Exercise 7: Finnish - Spanish dictionary")
print("This program will store some finnish to spanish words in a dictionary.\n")

finspa_dict = {
    "moi": "hola",
    "heippa": "adios",
    "koti": "casa",
    "numero": "numero",
    "puu": "arbol",
    "jarvi": "lago",
    "peruna": "patata",
    "näkki": "salsicha",
    "kirjasto": "biblioteca",
    "auto": "cotxe",
    "plkupyörä" : "bicicleta",
    }

print(f"The Finnish-Spanish dictionary contains: {finspa_dict} \n")
print(f"The keys (finnish words) of the dictionary are: {finspa_dict.keys()}\n")
print(f"The values (spanish words) of the dictionary are: {finspa_dict.values()}")

print("\nThank you for playing.")

print("Santiago Sala")
print("Week 4 Exercise 1: Calculate the sum of values")
print("This program will calculate the sum of values from 1 to 5")

initial_value = 1
while_result = initial_value

while initial_value < 5:    
    initial_value += 1
    while_result += initial_value


for_result = 0
for x in range(1, 6):
    for_result += x
    
    




print("The result of the WHILE loop is: " + str(while_result))
print("The result of the FOR loop is: " + str(for_result))

print("Thank you for playing")
